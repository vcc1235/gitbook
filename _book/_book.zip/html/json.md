~~~ makefile
  "donate",
 "splitter",
 "anchor-navigation-ex",
 "-sharing",
 "sharing-plus",
 "-include-codeblock",
 "-highlight",
 "disqus",
 "fontsettings",
 "hide-element",
 "chapter-fold",
 "prism-themes",
 "advanced-emoji",
 "klipse",
 "emphasize",
 "graph",
 "code",
 "tbfed-pagefooter",
 "github-buttons"
~~~



